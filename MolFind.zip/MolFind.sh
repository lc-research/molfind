#! /bin/bash
dir=$(cd -P "$(dirname "$0")" && pwd -P)
cd $dir
java -Xmx2g -jar MolFind.jar