Compiling with gfortran
gfortran mobcal.f -o mobcal -fno-automatic -std=legacy
gfortran mobcal_N2.f -o mobcal_N2 -fno-automatic -std=legacy